<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * This file sets up a settings page for configuring newsletter PDF output.
 * It registers two example settings:
 *  - pdf_header_logo_url: URL of the header logo
 *  - pdf_date_format: The date format used in the PDF
 *
 * More fields can be easily added as needed.
 */

// Hook to add the settings page link under the "Settings" menu
add_action('admin_menu', 'wr_pdf_settings_menu');
function wr_pdf_settings_menu() {
    add_options_page(
        'Newsletter PDF Settings',    // Page title
        'PDF Settings',               // Menu title
        'manage_options',             // Capability
        'wr-pdf-settings',            // Menu slug
        'wr_pdf_settings_page'        // Callback function
    );
}

// Hook to register settings
add_action('admin_init', 'wr_register_pdf_settings');
function wr_register_pdf_settings() {
    // Register two settings fields and tie them to a settings group
    register_setting('wr_pdf_settings_group', 'pdf_header_logo_url', [
        'type' => 'string',
        'sanitize_callback' => 'esc_url_raw',
        'default' => ''
    ]);

    register_setting('wr_pdf_settings_group', 'pdf_date_format', [
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'default' => 'F j, Y'
    ]);

    // Add a section for the PDF settings
    add_settings_section(
        'wr_pdf_settings_section',
        'PDF Configuration',   // Title of the section
        '__return_false',      // Optional callback for section description
        'wr-pdf-settings'      // Page slug where this section appears
    );

    // Add fields to the section
    add_settings_field(
        'pdf_header_logo_url',                      // Field ID
        'Header Logo URL',                          // Field Title
        'wr_pdf_header_logo_url_callback',          // Callback function
        'wr-pdf-settings',                          // Page slug
        'wr_pdf_settings_section'                   // Section ID
    );

    add_settings_field(
        'pdf_date_format',
        'Date Format',
        'wr_pdf_date_format_callback',
        'wr-pdf-settings',
        'wr_pdf_settings_section'
    );
}

// Callback for the Header Logo URL field
function wr_pdf_header_logo_url_callback() {
    $option = get_option('pdf_header_logo_url', '');
    echo '<input type="text" name="pdf_header_logo_url" value="' . esc_attr($option) . '" style="width:100%;" />';
    echo '<p class="description">Enter the full URL to the header logo to be used in the PDF.</p>';
}

// Callback for the Date Format field
function wr_pdf_date_format_callback() {
    $option = get_option('pdf_date_format', 'F j, Y');
    echo '<input type="text" name="pdf_date_format" value="' . esc_attr($option) . '" style="width:100%;" />';
    echo '<p class="description">Enter a valid PHP date format string. Default is "F j, Y" (e.g. March 10, 2024).</p>';
}

// Render the settings page
function wr_pdf_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    ?>
    <div class="wrap">
        <h1>Newsletter PDF Settings</h1>
        <form method="post" action="options.php">
            <?php 
            // Output security fields for the registered setting "wr_pdf_settings_group"
            settings_fields('wr_pdf_settings_group');
            // Output setting sections and their fields
            do_settings_sections('wr-pdf-settings');
            // Output save settings button
            submit_button();
            ?>
        </form>
    </div>
    <?php
}
