(function($) {
    // Global initialization flag
    window.blockManagerInitialized = false;
    
    // Initialize sortable for posts
    window.initializeSortable = function(block) {
        var sortableList = block.find('ul.sortable-posts');
        if (sortableList.length) {
            sortableList.sortable({
                handle: '.story-drag-handle',
                update: function(event, ui) {
                    var $block = ui.item.closest('.block-item');
                    var $storyCount = $block.find('.block-story-count');
                    
                    // Switch to manual mode if user manually sorts
                    if ($storyCount.val() !== 'disable') {
                        $storyCount.val('disable');
                    }
                    
                    sortableList.find('li').each(function(index) {
                        $(this).find('.post-order').val(index);
                    });
                    updatePreview();
                }
            });
        }
    };

    // Handle block type changes (show/hide fields)
    window.handleBlockTypeChange = function(block, blockType) {
        block.find('.content-block').hide();
        block.find('.html-block').hide();
        block.find('.wysiwyg-block').hide();
        block.find('.category-select').hide();
        block.find('.template-select').hide();
        block.find('.date-range-row').hide();
        block.find('.story-count-row').hide();

        if (blockType === 'content') {
            block.find('.content-block').show();
            block.find('.category-select').show();
            block.find('.template-select').show();
            block.find('.date-range-row').show();
            block.find('.story-count-row').show();
        } else if (blockType === 'html') {
            block.find('.html-block').show();
        } else if (blockType === 'wysiwyg') {
            block.find('.wysiwyg-block').show();
        }
    };

    // Initialize events for a block
window.initializeBlockEvents = function(block) {
    // Add a debounce flag
    let updateInProgress = false;
    
    // Initial setup
    initializeSortable(block);
    var blockType = block.find('.block-type').val();
    handleBlockTypeChange(block, blockType);
        
    // Track initial state
    const initialCategory = block.find('.block-category').val();
    const initialStoryCount = block.find('.block-story-count').val();

    // Handle story count changes
    block.find('.block-story-count').off('change').on('change', function() {
        const $block = $(this).closest('.block-item');
        const categoryId = $block.find('.block-category').val();
        const dateRange = $block.find('.block-date-range').val();
        const blockIndex = $block.data('index');
        const storyCount = $(this).val();

        if (categoryId) {
            if (!updateInProgress) {
                updateInProgress = true;
                loadBlockPosts($block, categoryId, blockIndex, dateRange, storyCount).then(() => {
                    setTimeout(() => {
                        updatePreview();
                        updateInProgress = false;
                    }, 250);
                });
            }
        }
    });

    // Only do initial load if needed
    if (initialCategory) {
        const dateRange = block.find('.block-date-range').val();
        const blockIndex = block.data('index');

        // Create a promise wrapper
        new Promise((resolve) => {
            loadBlockPosts(block, initialCategory, blockIndex, dateRange, initialStoryCount);
            resolve();
        }).then(() => {
            if (!updateInProgress) {
                updateInProgress = true;
                setTimeout(() => {
                    updatePreview();
                    updateInProgress = false;
                }, 250);
            }
        });
    }
        // Modify event handlers to use debounce
        block.find('.block-category, .block-date-range, .block-story-count').off('change').on('change', function() {
        if (updateInProgress) return;
        
        updateInProgress = true;
        const $block = $(this).closest('.block-item');
        const categoryId = $block.find('.block-category').val();
        const dateRange = $block.find('.block-date-range').val();
        const blockIndex = $block.data('index');
        const storyCount = $block.find('.block-story-count').val();

        if (categoryId) {
            new Promise((resolve) => {
                loadBlockPosts($block, categoryId, blockIndex, dateRange, storyCount);
                resolve();
            }).then(() => {
                setTimeout(() => {
                    updatePreview();
                    updateInProgress = false;
                }, 250);
            });
        }
    });

        // When WYSIWYG or HTML content changes, update preview
        block.find('.html-block textarea, .wysiwyg-block textarea').on('input', function() {
            if (!updateInProgress) {
                updateInProgress = true;
                setTimeout(() => {
                    updatePreview();
                    updateInProgress = false;
                }, 250);
            }
        });

        // Block type change
        block.find('.block-type').off('change').on('change', function() {
            var newBlockType = $(this).val();
            handleBlockTypeChange(block, newBlockType);
            if (!updateInProgress) {
                updateInProgress = true;
                setTimeout(() => {
                    updatePreview();
                    updateInProgress = false;
                }, 250);
            }
        });
    };

    // Load block posts via AJAX
    window.loadBlockPosts = function(block, categoryId, currentIndex, dateRange, storyCount) {
        // Get current selections for this block
        var savedSelections = {};
        
        // First get any checked checkboxes
        block.find('input[type="checkbox"][name*="[posts]"][name*="[selected]"]:checked').each(function() {
            var $checkbox = $(this);
            var postId = $checkbox.closest('li').data('post-id');
            var $orderInput = $checkbox.closest('li').find('.post-order');
            savedSelections[postId] = {
                selected: true,
                order: $orderInput.length ? $orderInput.val() : '0'
            };
        });
        
        // Then get any hidden inputs that store saved selections
        block.find('input[type="hidden"][name*="[posts]"][name*="[saved_selections]"]').each(function() {
            try {
                var savedData = JSON.parse($(this).val());
                if (savedData && typeof savedData === 'object') {
                    Object.keys(savedData).forEach(function(postId) {
                        if (savedData[postId].selected) {
                            savedSelections[postId] = savedData[postId];
                        }
                    });
                }
            } catch (e) {
                console.error('Error parsing saved selections:', e);
            }
        });

        // Also check for any data-was-selected attributes
        block.find('li[data-post-id][data-was-selected="1"]').each(function() {
            var $li = $(this);
            var postId = $li.data('post-id');
            var $orderInput = $li.find('.post-order');
            savedSelections[postId] = {
                selected: true,
                order: $orderInput.length ? $orderInput.val() : '0'
            };
        });

        var data = {
            action: 'load_block_posts',
            security: newsletterData.nonceLoadPosts,
            category_id: categoryId,
            block_index: currentIndex,
            date_range: dateRange,
            story_count: storyCount,
            newsletter_slug: newsletterData.newsletterSlug,
            saved_selections: JSON.stringify(savedSelections)
        };

        console.log('Loading posts with saved selections:', savedSelections);

        return $.ajax({
            url: newsletterData.ajaxUrl,
            method: 'POST',
            dataType: 'json',
            data: data,
            beforeSend: function() {
                block.find('.block-posts').addClass('loading');
            },
            success: function(response) {
                block.find('.block-posts').removeClass('loading');
                if (response.success) {
                    block.find('.block-posts').html(response.data);
                    
                    // After loading new content, restore any saved selections
                    Object.keys(savedSelections).forEach(function(postId) {
                        var selection = savedSelections[postId];
                        if (selection.selected) {
                            var $li = block.find('li[data-post-id="' + postId + '"]');
                            if ($li.length) {
                                var $checkbox = $li.find('input[type="checkbox"][name*="[selected]"]');
                                var $orderInput = $li.find('.post-order');
                                
                                if ($checkbox.length) {
                                    $checkbox.prop('checked', true);
                                }
                                if ($orderInput.length && selection.order) {
                                    $orderInput.val(selection.order);
                                }
                            }
                        }
                    });
                    
                    initializeSortable(block);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                block.find('.block-posts').removeClass('loading');
            }
        });
    };

    // Add a new block
    window.addBlock = function() {
        var blockIndex = $('#blocks-container .block-item').length;
        var blockHtml = `
            // Your existing block HTML template
        `;

        $('#blocks-container').append(blockHtml);
        var newBlock = $('#blocks-container .block-item').last();
        initializeBlockEvents(newBlock);

        // Reinitialize accordion for all blocks
        $("#blocks-container").accordion('destroy').accordion({
            header: ".block-header",
            collapsible: true,
            active: blockIndex,
            heightStyle: "content"
        });

        // After adding a new block, update the preview
        updatePreview();
    };

    $(document).ready(function() {
        // Prevent multiple initializations
        if (window.blockManagerInitialized) {
            return;
        }
        window.blockManagerInitialized = true;

        if ($.fn.accordion) {
            $('#blocks-container').accordion({
                header: '.block-header',
                icons: false,
                heightStyle: "content",
                collapsible: true,
                active: false
            });
        }

        // Track initialization of blocks
        var totalBlocks = $('#blocks-container .block-item').length;
        var initializedBlocks = 0;
        var loadPromises = [];

        // Initialize existing blocks
        $('#blocks-container .block-item').each(function() {
            var $block = $(this);
            initializeBlockEvents($block);
        });

        // Remove block triggers a preview update
        $(document).on('click', '.remove-block', function() {
            var block = $(this).closest('.block-item');
            block.remove();
            updatePreview();
        });
    });
})(jQuery);