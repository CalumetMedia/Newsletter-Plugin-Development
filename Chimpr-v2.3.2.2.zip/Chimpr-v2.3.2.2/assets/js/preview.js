(function($) {
    // Single instance of any running preview update
    let previewUpdatePromise = null;

    window.generatePreview = function() {
        // If there's already a preview update in progress, wait for it
        if (previewUpdatePromise) {
            return previewUpdatePromise;
        }

        // Store the current state of all checkboxes and their order
        var savedState = {};
        $('.block-item').each(function() {
            var $block = $(this);
            var blockIndex = $block.data('index');
            savedState[blockIndex] = {
                storyCount: $block.find('.block-story-count').val(),
                selections: {}
            };
            
            $block.find('input[type="checkbox"][name*="[posts]"][name*="[selected]"]').each(function() {
                var $checkbox = $(this);
                var postId = $checkbox.closest('li').data('post-id');
                var $orderInput = $checkbox.closest('li').find('.post-order');
                savedState[blockIndex].selections[postId] = {
                    checked: $checkbox.is(':checked'),
                    order: $orderInput.length ? $orderInput.val() : '0'
                };
            });
        });

        var formData = $('#blocks-form').serializeArray();
        formData.push({ name: 'action', value: 'generate_preview' });
        formData.push({ name: 'newsletter_slug', value: newsletterData.newsletterSlug });
        formData.push({ name: 'security', value: newsletterData.nonceGeneratePreview });
        formData.push({ name: 'saved_selections', value: JSON.stringify(savedState) });

        // Create and store the promise
        previewUpdatePromise = $.ajax({
            url: newsletterData.ajaxUrl,
            method: 'POST',
            dataType: 'json',
            data: formData
        }).then(function(response) {
            if (response.success) {
                $('#preview-content').html(response.data);
                
                // Restore state after preview loads
                $('.block-item').each(function() {
                    var $block = $(this);
                    var blockIndex = $block.data('index');
                    var state = savedState[blockIndex];
                    
                    if (state) {
                        $block.find('.block-story-count').val(state.storyCount);
                        Object.keys(state.selections).forEach(function(postId) {
                            var selection = state.selections[postId];
                            var $li = $block.find('li[data-post-id="' + postId + '"]');
                            if ($li.length) {
                                var $checkbox = $li.find('input[type="checkbox"][name*="[selected]"]');
                                var $orderInput = $li.find('.post-order');
                                
                                if ($checkbox.length) {
                                    $checkbox.prop('checked', selection.checked);
                                }
                                if ($orderInput.length) {
                                    $orderInput.val(selection.order);
                                }
                            }
                        });
                    }
                });
            }
        }).catch(function(error) {
            console.error('Preview generation failed:', error);
        }).finally(function() {
            // Clear the stored promise when done
            previewUpdatePromise = null;
        });

        return previewUpdatePromise;
    };

    // Debounced updatePreview function
    window.updatePreview = function() {
        if (window.updatePreviewTimeout) {
            clearTimeout(window.updatePreviewTimeout);
        }
        
        window.updatePreviewTimeout = setTimeout(function() {
            generatePreview();
        }, 250);
    };

})(jQuery);