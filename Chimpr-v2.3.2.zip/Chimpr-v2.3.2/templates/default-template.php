<div class="post">
    <h3><a href="{permalink}">{title}</a></h3>
    {if_thumbnail}
        <a href="{permalink}"><img src="{thumbnail_url}" alt="{title}" width="100%"></a>
    {/if_thumbnail}
    <div class="post-excerpt">
        
    </div>
    <a href="{permalink}" class="read-more">Read More</a> <br><br><br>
</div>
